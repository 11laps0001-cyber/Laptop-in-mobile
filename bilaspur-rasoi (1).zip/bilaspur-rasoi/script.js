// ---- Mobile menu ----
const menuBtn = document.getElementById('menuBtn');
const mobileNav = document.getElementById('mobileNav');
menuBtn.addEventListener('click', () => {
  const open = mobileNav.classList.toggle('open');
  menuBtn.setAttribute('aria-expanded', open);
});
mobileNav.addEventListener('click', e => {
  if (e.target.tagName === 'A') {
    mobileNav.classList.remove('open');
    menuBtn.setAttribute('aria-expanded', false);
  }
});

// ---- Weekly menu data ----
const DAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

const BREAKFAST = [
  ['Poha'],
  ['Dry Maggi'],
  ['Aalu Puri'],
  ['Pasta', 'Tomato sauce'],
  ['Chowmein', 'Tomato sauce'],
  ['Aalu Paratha', 'Curd'],
  ['Suji Halwa']
];

const TAIL = ['Salad', 'Green chutney'];
const sabjiMeal = ['Seasonal sabji', 'Rice', 'Dal fry', 'Roti', ...TAIL];

// Lunch & dinner are the same for veg and non-veg, except where marked below.
const MEALS = {
  veg: [
    { lunch: ['Soyabean onion', 'Rice', 'Dal fry', 'Roti', ...TAIL], dinner: sabjiMeal },
    { lunch: ['Seasonal sabji', 'Dal palak', 'Rice', 'Roti', ...TAIL], dinner: sabjiMeal },
    { lunch: ['Chole curry', 'Dal fry', 'Rice', 'Puri', ...TAIL], dinner: sabjiMeal },
    { lunch: sabjiMeal, dinner: sabjiMeal },
    { lunch: ['Boondi kadhi', 'Rice', 'Aalu bhujia / fry', 'Roti', ...TAIL], dinner: sabjiMeal },
    { lunch: ['Aalu bhujia / fry', 'Rice', 'Dal fry', 'Roti', ...TAIL], dinner: ['Chana aalu', 'Rice', 'Dal fry', 'Roti', ...TAIL] },
    { lunch: sabjiMeal, dinner: ['Matar paneer', 'Rice', 'Dal fry', 'Puri', 'Sweet sevai kheer', ...TAIL], dinnerAlt: 'Alternate: Veg biryani or a paneer meal' }
  ]
};
MEALS.nonveg = MEALS.veg.map(d => ({ ...d }));
MEALS.nonveg[2].dinner = ['Egg curry', 'Dal fry', 'Rice', 'Roti', 'Salad', 'Papad', 'Green chutney'];
MEALS.nonveg[6].dinner = ['Chicken curry', 'Rice', 'Dal fry', 'Puri', 'Sweet sevai kheer', 'Salad', 'Papad', 'Green chutney'];
delete MEALS.nonveg[6].dinnerAlt;

const SABJI = ['Bhindi', 'Beans', 'Gobhi', 'Parwal', 'Green matar', 'Barbatti', 'Shimla', 'Semi', 'Palak', 'Mix veg', 'Lauki + chana dal', 'Baigan + semi', 'Pattagobhi + gajar'];
const BHAJI = ['Palak', 'Lal bhaji'];
const SPECIAL_DAYS = [2, 6]; // Wednesday & Sunday

// ---- Render menu ----
const listEl = document.getElementById('menuList');
const todayIdx = (new Date().getDay() + 6) % 7; // JS: 0 = Sunday -> index 6
let type = 'veg';

const isNV = s => /egg|chicken/i.test(s);
const mark = (name, plan) => `<i class="vm ${plan === 'nonveg' && isNV(name) ? 'nonveg' : 'veg'}" title="${plan === 'nonveg' && isNV(name) ? 'Non-veg' : 'Veg'}"></i>`;
const COMMON = ['Salad', 'Green chutney']; // shown once in the legend

function mealHTML(items, plan, alt) {
  const [main, ...others] = items;
  const rice = others.includes('Rice');
  const extra = others.filter(i => i !== 'Rice' && !COMMON.includes(i));
  return `<p class="m-main">${mark(main, plan)}<b>${main}</b>${rice ? '<span class="plus">+</span><b>Rice</b>' : ''}</p>
    ${extra.length ? `<p class="m-extra">${extra.join(' · ')}</p>` : ''}
    ${alt ? `<p class="m-alt">${alt}</p>` : ''}`;
}

function breakfastHTML(items) {
  const [main, ...withs] = items;
  return `<p class="m-main"><b>${main}</b></p>${withs.length ? `<p class="m-extra">with ${withs.join(', ').toLowerCase()}</p>` : ''}`;
}

const daysEl = document.getElementById('days');
const WEEK_ORDER = [6, 0, 1, 2, 3, 4, 5]; // week starts on Sunday
let sel = todayIdx;

function renderDays() {
  daysEl.innerHTML = WEEK_ORDER.map(i =>
    `<button role="tab" class="${sel === i ? 'on' : ''}" data-day="${i}" aria-selected="${sel === i}"><span>${DAYS[i].slice(0, 3)}</span>${SPECIAL_DAYS.includes(i) ? '<em>★</em>' : ''}</button>`
  ).join('');
}

function dayHTML(d, i) {
  const m = MEALS[type][i];
  const today = i === todayIdx;
  const special = SPECIAL_DAYS.includes(i);
  return `<article class="day${today ? ' today' : ''}">
      <header class="d-head"><h3>${d}</h3>${today ? '<em class="t-today">Today</em>' : ''}${special ? '<em class="t-spec">★ Special</em>' : ''}</header>
      <div class="d-meals">
        <div class="c"><span class="lbl">Lunch</span>${mealHTML(m.lunch, type)}</div>
        <div class="c"><span class="lbl">Dinner</span>${mealHTML(m.dinner, type, m.dinnerAlt)}</div>
        <div class="c bf"><span class="lbl">Breakfast <i>Add-on</i></span>${breakfastHTML(BREAKFAST[i])}</div>
      </div>
    </article>`;
}

function bfRowHTML(i) {
  const weekend = i === 5 || i === 6;
  const today = i === todayIdx;
  return `<article class="day bf-only${today ? ' today' : ''}">
      <header class="d-head"><h3>${DAYS[i]}</h3>${today ? '<em class="t-today">Today</em>' : ''}${weekend ? '<em class="t-spec">Weekend ₹300</em>' : ''}</header>
      <div class="d-meals"><div class="c bf"><span class="lbl">Breakfast <i>Add-on</i></span>${breakfastHTML(BREAKFAST[i])}</div></div>
    </article>`;
}

function renderMenu() {
  const bf = type === 'breakfast';
  daysEl.style.display = bf ? 'none' : '';
  if (bf) {
    listEl.innerHTML = `<div class="bf-opts">
        <div><b>All days</b><span>Sunday to Saturday</span><strong>₹1100 <small>/ month</small></strong></div>
        <div class="wk"><b>Weekend only</b><span>Saturday &amp; Sunday</span><strong>₹300</strong></div>
      </div>` + WEEK_ORDER.map(bfRowHTML).join('');
    return;
  }
  renderDays();
  listEl.innerHTML = dayHTML(DAYS[sel], sel);
}

daysEl.addEventListener('click', e => {
  const b = e.target.closest('[data-day]');
  if (!b) return;
  sel = +b.dataset.day;
  renderMenu();
});

renderMenu();
document.getElementById('sabjiList').innerHTML = SABJI.map(s => `<li>${s}</li>`).join('');
document.getElementById('bhajiList').innerHTML = BHAJI.map(s => `<li>${s}</li>`).join('');

document.querySelectorAll('.seg [data-type]').forEach(btn => {
  btn.addEventListener('click', () => {
    type = btn.dataset.type;
    document.querySelectorAll('.seg [data-type]').forEach(b => {
      const on = b === btn;
      b.classList.toggle('on', on);
      b.setAttribute('aria-selected', on);
    });
    renderMenu();
  });
});

// ---- Price breakdown ----
const planSelect = document.getElementById('planSelect');
const qtyWrap = document.getElementById('qtyWrap');
const qtyInput = document.getElementById('qty');
const bfBox = document.getElementById('addBreakfast');
const foilBox = document.getElementById('addFoil');
const billRows = document.getElementById('billRows');
const billTotal = document.getElementById('billTotal');
const BREAKFAST_PRICE = 1100, WEEKEND_BF_PRICE = 300, FOIL_PRICE = 300;
const rupee = n => '₹' + n;

function breakdown() {
  const opt = planSelect.selectedOptions[0];
  const trial = opt.dataset.kind === 'trial';
  const price = +opt.dataset.price;
  const rows = [];
  if (trial) {
    const q = Math.min(10, Math.max(1, parseInt(qtyInput.value, 10) || 1));
    rows.push({ l: `${opt.dataset.label} <small>₹${price} × ${q} meal${q > 1 ? 's' : ''}</small>`, t: `${opt.dataset.label} (${q} meal${q > 1 ? 's' : ''})`, v: price * q });
  } else {
    rows.push({ l: opt.dataset.label, t: opt.dataset.label, v: price });
    if (bfBox.value === 'full') rows.push({ l: 'Breakfast add-on <small>all days, per month</small>', t: 'Breakfast add-on (all days, per month)', v: BREAKFAST_PRICE });
    if (bfBox.value === 'weekend') rows.push({ l: 'Weekend breakfast <small>Sat &amp; Sun</small>', t: 'Weekend breakfast (Sat & Sun)', v: WEEKEND_BF_PRICE });
    if (foilBox.checked) rows.push({ l: 'Silver foil packing', t: 'Silver foil packing', v: FOIL_PRICE });
  }
  return { trial, rows, total: rows.reduce((s, r) => s + r.v, 0) };
}

function renderBill() {
  const { trial, rows, total } = breakdown();
  qtyWrap.hidden = !trial;
  [bfBox, foilBox].forEach(b => { b.disabled = trial; b.closest('label').classList.toggle('off', trial); if (trial) { if (b.type === 'checkbox') b.checked = false; else b.value = ''; } });
  billRows.innerHTML = rows.map(r => `<li><span>${r.l}</span><b>${rupee(r.v)}</b></li>`).join('');
  billTotal.textContent = rupee(total);
}
[planSelect, qtyInput, bfBox, foilBox].forEach(el => el.addEventListener('input', renderBill));
renderBill();

// ---- Plan buttons pre-select the order form ----
document.querySelectorAll('[data-plan]').forEach(btn => {
  btn.addEventListener('click', () => {
    const wanted = btn.dataset.plan + ' ';
    const idx = [...planSelect.options].findIndex(o => o.text.startsWith(wanted));
    if (idx >= 0) planSelect.selectedIndex = idx;
    renderBill();
  });
});
document.querySelectorAll('[data-addon]').forEach(btn => {
  btn.addEventListener('click', () => {
    if (planSelect.selectedOptions[0].dataset.kind === 'trial') planSelect.selectedIndex = 2;
    bfBox.value = btn.dataset.addon === 'weekend' ? 'weekend' : 'full';
    renderBill();
  });
});

// ---- Order form -> opens WhatsApp directly ----
const WHATSAPP = '919109889799';
const form = document.getElementById('orderForm');
const formErr = document.getElementById('formErr');
form.addEventListener('submit', e => {
  e.preventDefault();
  const d = Object.fromEntries(new FormData(form).entries());
  if (!d.name.trim() || !d.phone.trim() || !d.address.trim()) {
    formErr.hidden = false;
    return;
  }
  formErr.hidden = true;
  const { rows, total } = breakdown();
  const lines = [
    'Hello Bilaspur Rasoi, I would like to book:',
    '',
    `Name: ${d.name.trim()}`,
    `Phone: ${d.phone.trim()}`,
    `Address: ${d.address.trim()}`,
    '',
    '*Price breakdown*',
    ...rows.map(r => `- ${r.t}: ${rupee(r.v)}`),
    `*Total: ${rupee(total)}*`
  ];
  window.location.href = `https://wa.me/${WHATSAPP}?text=${encodeURIComponent(lines.join('\n'))}`;
});
